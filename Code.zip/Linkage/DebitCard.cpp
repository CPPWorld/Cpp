#include <iostream>

extern int nBalanceAmount; // Now compiler knows that the variable is
                           // defined else where.
                           // Compiler just need to know the type.
void DebitCardPay( const int nAmountToPay )
{
    nBalanceAmount = nBalanceAmount - nAmountToPay;
    std::cout << "-------------DebitCard Pay Reciept-------------\n";
    std::cout << "Paid Amount : " << nAmountToPay << '\n';
    std::cout << "Balance Amount : " << nBalanceAmount << '\n';
    std::cout << "--------------------------------------------\n";
}