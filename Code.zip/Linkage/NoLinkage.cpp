#include <iostream>

void FDBalance()
{
   int Amount = 50000; // No linkage
   std::cout << "Fixed Deposit Balance" << Amount << "\n";
}

void CarLoan()
{
    int Amount = 25000; // No linkage
    std::cout << "Car Loan" << Amount << "\n";
}

//int main()
//{
//    FDBalance();
//    CarLoan();
//    return 0;
//}