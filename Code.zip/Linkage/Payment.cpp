void DebitCardPay( const int nAmountToPay );
void GooglePay( const int nAmountToPay );

int main()
{
    DebitCardPay( 100 );
    GooglePay( 200 );
    return 0;
}