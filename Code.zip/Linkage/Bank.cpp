#include <iostream>

static int nBalanceAmount = 5000; // static linkage


static void BalanceAmount()
{
    std::cout << "Bank Balance Amount:" << nBalanceAmount << "\n";
}

void PaySalaryToBankEmployee( int nSalary )
{
    std::cout << "-------------------------------------\n";

    BalanceAmount();

    nBalanceAmount = nBalanceAmount - nSalary;
    std::cout <<  "Amount deducted from Bank account:" << nSalary << "\n";
    
    BalanceAmount();
    std::cout <<  "-------------------------------------\n";
}