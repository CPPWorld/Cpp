#include <iostream>

static int nBalanceAmount = 3000;  // static linkage

static void BalanceAmount()
{
   std::cout << "Software company balance amount:" << nBalanceAmount << "\n";
}

void PaySalaryToSoftwareEngineer( int nSalary )
{
    std::cout << "-------------------------------------\n";
    BalanceAmount();

    nBalanceAmount = nBalanceAmount - nSalary;
    std::cout << "Amount deducted from Software company account:" << nSalary << "\n";

    BalanceAmount();

    std::cout << "-------------------------------------\n";
}