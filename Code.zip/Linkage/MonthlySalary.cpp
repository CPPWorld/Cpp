
void PaySalaryToSoftwareEngineer( int nSalary );
void PaySalaryToBankEmployee( int nSalary );

//int main()
//{
//    PaySalaryToSoftwareEngineer( 2000 );
//    PaySalaryToBankEmployee( 1500 );
//    return 0;
//}