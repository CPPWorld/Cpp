#include <iostream>

int main()
{
    std::cout << "Visual Studio Version : 2017 v15.8 onwards";
    std::cout << "Shortcut 1";
    std::cout << "Multi-Caret Support";
    std::cout << "Key combination : Ctrl + Alt + Click";

    std::cout << "Visual Studio Version : 2017 v15.8 onwards";
    std::cout << "Shortcut 2"<< std::endl;
    std::cout << "Multi-Caret Support"<< std::endl;
    std::cout << "Key combination : Shift + Alt + ." << ": for selecting the next match one by one" << std::endl;
    std::cout << "Key combination : Shift + Alt + ," << ": for de-selecting the last match one by one" << std::endl;


    std::cout << "Visual Studio Version : 2017 v15.6 onwards";
    std::cout << "Shortcut 3";
    std::cout << "Duplicate Code";
    std::cout << "Key combination : Ctrl + D";

    std::cout << "Visual Studio Version : 2017 v15.8 onwards";
    std::cout << "Shortcut 4";
    std::cout << "Go To Last Edited Location";
    std::cout << "Key combination : Ctrl + Shift + Backspace";


    
    std::cout << "Visual Studio Version : 2017 v15.5 onwards";
    std::cout << "Shortcut 5";
    std::cout << "Expand/Contract Selection";
    std::cout << "Key combination : Shift + Alt + +";
    std::cout << "Key combination : Shift + Alt + -";
    {
        int i = 10;
        {
            int j =20;
            {
                int k = 30;
                int l = (1 +3 );
            }
        }
    }

}