#include <iostream>

int nBalanceAmount = 100000; // Actual defintion

void DisplayBankBalance()
{
    std::cout << "-------------Balance Reciept----------------\n";
    std::cout << "Bank Balance : " << nBalanceAmount << '\n';
    std::cout << "--------------------------------------------\n";
}